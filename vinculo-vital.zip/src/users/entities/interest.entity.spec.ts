import { InterestEntity } from './interest.entity';

describe('InterestEntity', () => {
  it('should be defined', () => {
    expect(new InterestEntity()).toBeDefined();
  });
});
